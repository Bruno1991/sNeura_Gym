# s_Neura_Gym — Scripted Bot

External Minecraft Bedrock agent used as the deterministic baseline
for the s_Neura_Gym project.

## Purpose

The Scripted Bot is an external player/client.

It does not run inside the Minecraft Bedrock server.

The server is an independent process and must not be modified by
the bot project.

## Architecture

```text
s_Neura_Gym
└── bedrock_bot
    ├── Neural_Bot
    └── Scripted_Bot
        ├── src
        │   ├── config.js
        │   ├── index.js
        │   └── telemetry.js
        │
        ├── telemetry
        ├── package.json
        └── README.md
