/**
 * s_Neura_Gym - Scripted Bot
 *
 * Responsibility:
 * Starts the external Minecraft Bedrock client and coordinates
 * the basic lifecycle between perception and action.
 *
 * This file does not contain gameplay decision logic.
 */

const bedrock = require('bedrock-protocol')

const config = require('./config')
const telemetry = require('./telemetry')
const PlayerState = require('./perception/player_state')
const Movement = require('./action/movement')

const playerState = new PlayerState()

let movement = null
let initialized = false

console.log('')
console.log('='.repeat(72))
console.log('              s_Neura_Gym - Scripted Bot')
console.log('='.repeat(72))
console.log('')
console.log(`Servidor : ${config.server.host}:${config.server.port}`)
console.log(`Versão   : ${config.server.version}`)
console.log(`Jogador  : ${config.player.username}`)
console.log('')

telemetry.emit('bot_start', {
  server: {
    host: config.server.host,
    port: config.server.port,
    version: config.server.version
  },
  username: config.player.username,
  spawn: config.environment.spawn
})

const client = bedrock.createClient({
  host: config.server.host,
  port: config.server.port,
  version: config.server.version,
  username: config.player.username,
  offline: config.player.offline,

  onMsaCode: (data) => {
    console.log('')
    console.log('[AUTH] Autenticação Microsoft necessária.')
    console.log(`[AUTH] Código: ${data.user_code}`)
    console.log(`[AUTH] URL   : ${data.verification_uri}`)
    console.log('')
    console.log('[AUTH] Abra a URL acima e informe o código.')
    console.log('')
  }
})

movement = new Movement(client, playerState)

client.on('move_player', (packet) => {
  const updated = playerState.updateFromMovePlayer(packet)

  if (!updated) {
    return
  }

  const state = playerState.getSnapshot()

  telemetry.emit('player_position_updated', {
    runtimeEntityId: state.runtimeEntityId,
    position: state.position,
    rotation: state.rotation
  })

  console.log(
    `[PERCEPTION] Position: ` +
    `X=${state.position.x.toFixed(2)} ` +
    `Y=${state.position.y.toFixed(2)} ` +
    `Z=${state.position.z.toFixed(2)}`
  )

    if (!initialized && state.runtimeEntityId !== null) {
    initialized = true

    client.queue('set_local_player_as_initialized', {
      runtime_entity_id: BigInt(state.runtimeEntityId)
    })

    telemetry.emit('player_initialized', {
      runtimeEntityId: state.runtimeEntityId
    })

    console.log('[CLIENT] Jogador inicializado para o servidor.')

    movement.start()

    console.log('[ACTION] Sistema de movimento iniciado.')

    setTimeout(() => {
      console.log('[ACTION] Caminhando para frente por 5 segundos.')

      movement.walkForward()

      telemetry.emit('movement_started', {
        action: 'walk_forward',
        durationMs: 5000
      })

      setTimeout(() => {
        movement.stopWalking()

        telemetry.emit('movement_stopped', {
          action: 'walk_forward'
        })

        console.log('[ACTION] Caminhada encerrada.')
      }, 5000)
    }, 1000)
  }
})

client.on('connect', () => {
  console.log('[CLIENT] Transporte conectado.')
  telemetry.emit('transport_connected')
})

client.on('join', () => {
  console.log('[CLIENT] Bot entrou no servidor.')
  telemetry.emit('player_joined')
})

client.on('spawn', () => {
  console.log('[CLIENT] Bot recebeu spawn.')
  telemetry.emit('player_spawned')
})

client.on('disconnect', (reason) => {
  console.log('[CLIENT] Desconectado.')
  console.log(`[CLIENT] Motivo: ${reason}`)

  if (movement) {
    movement.stop()
  }

  telemetry.emit('player_disconnected', {
    reason
  })
})

client.on('error', (error) => {
  console.error('[CLIENT] Erro:', error)

  telemetry.emit('client_error', {
    message: error.message,
    stack: error.stack
  })
})

process.on('SIGINT', () => {
  console.log('')
  console.log('[SYSTEM] Encerrando Scripted Bot...')

  if (movement) {
    movement.stop()
  }

  telemetry.emit('bot_shutdown', {
    reason: 'SIGINT'
  })

  client.disconnect('Scripted Bot shutdown')

  process.exit(0)
})
