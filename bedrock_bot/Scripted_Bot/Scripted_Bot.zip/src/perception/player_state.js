/**
 * s_Neura_Gym - Scripted Bot
 *
 * Responsibility:
 * Observes and maintains the current state of the local player.
 *
 * MVP-002:
 * - Position X/Y/Z
 * - Pitch
 * - Yaw
 * - Head yaw
 * - Runtime entity ID
 * - Ground state
 * - Server tick
 *
 * This file does not make decisions and does not control movement.
 */

class PlayerState {
  constructor () {
    this.runtimeEntityId = null

    this.position = {
      x: null,
      y: null,
      z: null
    }

    this.rotation = {
      pitch: null,
      yaw: null,
      headYaw: null
    }

    this.onGround = false
    this.tick = null

    this.initialized = false
  }

  updateFromMovePlayer (packet) {
    if (!packet || !packet.position) {
      return false
    }

    if (this.runtimeEntityId === null) {
      this.runtimeEntityId = packet.runtime_id
    }

    if (packet.runtime_id !== this.runtimeEntityId) {
      return false
    }

    this.position = {
      x: packet.position.x,
      y: packet.position.y,
      z: packet.position.z
    }

    this.rotation = {
      pitch: packet.pitch,
      yaw: packet.yaw,
      headYaw: packet.head_yaw
    }

    this.onGround = packet.on_ground
    this.tick = packet.tick

    this.initialized = true

    return true
  }

  getSnapshot () {
    return {
      runtimeEntityId: this.runtimeEntityId,

      position: {
        x: this.position.x,
        y: this.position.y,
        z: this.position.z
      },

      rotation: {
        pitch: this.rotation.pitch,
        yaw: this.rotation.yaw,
        headYaw: this.rotation.headYaw
      },

      onGround: this.onGround,
      tick: this.tick,
      initialized: this.initialized
    }
  }
}

module.exports = PlayerState
