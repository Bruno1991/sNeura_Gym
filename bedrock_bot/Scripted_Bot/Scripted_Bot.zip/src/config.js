/**
 * s_Neura_Gym - Scripted Bot
 *
 * Responsibility:
 * Centralizes the configuration required by the external
 * Minecraft Bedrock client and its training environment.
 *
 * This file must not contain gameplay logic, telemetry logic,
 * decision-making, or perception behavior.
 */

module.exports = {
  server: {
    host: '10.9.21.15',
    port: 19132,
    version: '1.26.51'
  },

  player: {
    username: 'Saile_ScriptedBot',
    offline: false
  },

  environment: {
    spawn: {
      x: 79,
      y: 63,
      z: 1251
    }
  }
}
