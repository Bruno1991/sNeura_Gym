/**
 * s_Neura_Gym - Scripted Bot
 *
 * Responsibility:
 * Controls the local player's movement through the
 * Minecraft Bedrock PlayerAuthInput protocol.
 *
 * This file contains action primitives only.
 * It does not decide where the agent should go.
 */

class Movement {
  constructor (client, playerState) {
    this.client = client
    this.playerState = playerState

    this.tick = 0n
    this.timer = null

    this.walking = false
  }

  start () {
    if (this.timer !== null) {
      return
    }

    this.timer = setInterval(() => {
      this.update()
    }, 50)
  }

  stop () {
    if (this.timer === null) {
      return
    }

    clearInterval(this.timer)
    this.timer = null

    this.walking = false
  }

  walkForward () {
    this.walking = true
  }

  stopWalking () {
    this.walking = false
  }

  update () {
    const state = this.playerState.getSnapshot()

    if (!state.initialized) {
      return
    }

    if (
      state.position.x === null ||
      state.position.y === null ||
      state.position.z === null
    ) {
      return
    }

    const moveVector = this.walking
      ? { x: 0, z: 1 }
      : { x: 0, z: 0 }

    this.client.queue('player_auth_input', {
      pitch: state.rotation.pitch ?? 0,
      yaw: state.rotation.yaw ?? 0,

      position: {
        x: state.position.x,
        y: state.position.y,
        z: state.position.z
      },

      move_vector: moveVector,

      head_yaw: state.rotation.headYaw ?? state.rotation.yaw ?? 0,

      input_data: this.walking
        ? ['up']
        : [],

      input_mode: 'mouse',
      play_mode: 'normal',

      interaction_model: 'crosshair',

      interact_rotation: {
        x: 0,
        y: 0
      },

      tick: this.tick,

      delta: {
        x: 0,
        y: 0,
        z: 0
      },

      analogue_move_vector: moveVector,

      camera_orientation: {
        x: 0,
        y: 0,
        z: 0
      },

      raw_move_vector: moveVector
    })

    this.tick += 1n
  }
}

module.exports = Movement
