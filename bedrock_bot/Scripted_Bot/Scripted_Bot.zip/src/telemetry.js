/**
 * s_Neura_Gym - Scripted Bot
 *
 * Responsibility:
 * Provides the telemetry interface for the scripted agent.
 *
 * MVP-001 keeps telemetry in the console.
 * Persistent telemetry storage will be introduced in a later milestone.
 */

function timestamp () {
  return new Date().toISOString()
}

function emit (event, data = {}) {
  const record = {
    timestamp: timestamp(),
    event,
    data
  }

  console.log(
    `[TELEMETRY] ${JSON.stringify(record)}`
  )

  return record
}

module.exports = {
  emit
}
